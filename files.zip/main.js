const products = [
  { id:1, cat:'Laptopuri', name:'Laptop Dell XPS 15 – Intel Core i7, 16GB RAM, 512GB SSD', price:28999, rating:4.8, reviews:124, img:'https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=500&q=80', emoji:'💻', inStock:true },
  { id:2, cat:'Telefoane', name:'iPhone 15 Pro Max 256GB – Titanium Natural', price:24500, rating:4.9, reviews:342, img:'https://images.unsplash.com/photo-1632661674596-df8be070a5c5?w=500&q=80', emoji:'📱', inStock:true },
  { id:3, cat:'Telefoane', name:'Samsung Galaxy S24 Ultra 512GB', price:22300, rating:4.7, reviews:298, img:'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=500&q=80', emoji:'📱', inStock:true },
  { id:4, cat:'Laptopuri', name:'MacBook Pro 14" M3 Pro – 18GB RAM, 1TB SSD', price:45999, rating:5, reviews:187, img:'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=500&q=80', emoji:'💻', inStock:true },
  { id:5, cat:'Accesorii', name:'Sony WH-1000XM5 – Căști wireless cu noise cancelling', price:7899, rating:4.8, reviews:456, img:'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=500&q=80', emoji:'🎧', inStock:true },
  { id:6, cat:'Tablete', name:'iPad Pro 12.9" M2 – 256GB Wi-Fi', price:21999, rating:4.9, reviews:234, img:'https://images.unsplash.com/photo-1589739900266-43b2843f4c12?w=500&q=80', emoji:'📲', inStock:true },
  { id:7, cat:'Accesorii', name:'Logitech MX Master 3S – Mouse wireless', price:1899, rating:4.7, reviews:678, img:'https://images.unsplash.com/photo-1527814050087-3793815479db?w=500&q=80', emoji:'🖱️', inStock:true },
  { id:8, cat:'Monitoare', name:'Samsung 27" Monitor 4K UHD – 144Hz', price:8499, rating:4.6, reviews:189, img:'https://images.unsplash.com/photo-1547119957-637f8679db1e?w=500&q=80', emoji:'🖥️', inStock:true },
  { id:9, cat:'Wearables', name:'Apple Watch Series 9 – GPS + Cellular 45mm', price:9899, rating:4.8, reviews:523, img:'https://images.unsplash.com/photo-1544117519-31a4b719223d?w=500&q=80', emoji:'⌚', inStock:false },
  { id:10, cat:'Accesorii', name:'Keychron K8 Pro – Tastatură mecanică wireless', price:2199, rating:4.7, reviews:312, img:'https://images.unsplash.com/photo-1595225476474-87563907a212?w=500&q=80', emoji:'⌨️', inStock:true },
  { id:11, cat:'Accesorii', name:'AirPods Pro (2nd generation) cu USB-C', price:5499, rating:4.9, reviews:892, img:'https://images.unsplash.com/photo-1606741965509-717c3f54e4c5?w=500&q=80', emoji:'🎧', inStock:true },
  { id:12, cat:'Laptopuri', name:'Asus ROG Strix Gaming Laptop – RTX 4070, 32GB RAM', price:35999, rating:4.7, reviews:156, img:'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=500&q=80', emoji:'🎮', inStock:true },
];

const categoryMeta = {
  'Laptopuri':  { icon:'💻', desc:'Performanță maximă pentru muncă și gaming', img:'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&q=80' },
  'Telefoane':  { icon:'📱', desc:'Smartphone-uri de ultimă generație', img:'https://images.unsplash.com/photo-1592899677977-9c10002761d0?w=400&q=80' },
  'Tablete':    { icon:'📲', desc:'Tablete pentru productivitate și divertisment', img:'https://images.unsplash.com/photo-1589739900266-43b2843f4c12?w=400&q=80' },
  'Accesorii':  { icon:'🎧', desc:'Accesorii esențiale pentru gadgeturile tale', img:'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=400&q=80' },
  'Monitoare':  { icon:'🖥️', desc:'Monitoare 4K pentru muncă și gaming', img:'https://images.unsplash.com/photo-1547119957-637f8679db1e?w=400&q=80' },
  'Wearables':  { icon:'⌚', desc:'Smartwatch-uri și dispozitive purtabile', img:'https://images.unsplash.com/photo-1544117519-31a4b719223d?w=400&q=80' },
};

let cartCount = 0;
let currentPage = 'home';
let currentCategory = '';

function navigate(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));

  if (page.startsWith('cat-')) {
    const cat = page.replace('cat-', '');
    currentCategory = cat;
    openCategoryPage(cat);
    document.getElementById('page-category').classList.add('active');
    currentPage = 'category';
  } else if (page === 'home') {
    document.getElementById('page-home').classList.add('active');
    document.getElementById('nav-home').classList.add('active');
    currentPage = 'home';
  } else if (page === 'produse') {
    document.getElementById('page-produse').classList.add('active');
    document.getElementById('nav-produse').classList.add('active');
    filterAllProducts();
    currentPage = 'produse';
  } else if (page === 'oferte') {
    document.getElementById('page-oferte').classList.add('active');
    document.getElementById('nav-oferte').classList.add('active');
    currentPage = 'oferte';
  } else if (page === 'contact') {
    document.getElementById('page-contact').classList.add('active');
    document.getElementById('nav-contact').classList.add('active');
    currentPage = 'contact';
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
  location.hash = page;
}

function openCategoryPage(cat) {
  const meta = categoryMeta[cat] || { icon:'📦', desc:'Produse din categoria ' + cat };
  const catProducts = products.filter(p => p.cat === cat);

  document.getElementById('catBreadcrumb').textContent = cat;
  document.getElementById('catHeroTitle').textContent = cat;
  document.getElementById('catHeroDesc').textContent = meta.desc;
  document.getElementById('catHeroIcon').textContent = meta.icon;
  document.getElementById('catHeroCount').textContent = catProducts.length;

  document.getElementById('catPriceMin').value = 0;
  document.getElementById('catPriceMax').value = 50000;
  document.querySelectorAll('input[name="catstock"]').forEach(r => r.checked = r.value === 'toate');
  document.getElementById('catSortSelect').value = 'default';

  renderCatProducts(catProducts);

  const others = Object.keys(categoryMeta).filter(c => c !== cat);
  document.getElementById('relatedCatsList').innerHTML = others.map(c =>
    `<a class="related-cat-pill" onclick="navigate('cat-${c}')">${categoryMeta[c].icon} ${c}</a>`
  ).join('');
}

function filterCatProducts() {
  const min = parseInt(document.getElementById('catPriceMin').value) || 0;
  const max = parseInt(document.getElementById('catPriceMax').value) || 999999;
  const stockFilter = document.querySelector('input[name="catstock"]:checked').value;
  const sort = document.getElementById('catSortSelect').value;

  let list = products.filter(p => p.cat === currentCategory && p.price >= min && p.price <= max);
  if (stockFilter === 'stoc') list = list.filter(p => p.inStock);

  if (sort === 'price-asc') list.sort((a,b) => a.price - b.price);
  else if (sort === 'price-desc') list.sort((a,b) => b.price - a.price);
  else if (sort === 'rating') list.sort((a,b) => b.rating - a.rating);

  renderCatProducts(list);
}

function resetCatFilters() {
  document.getElementById('catPriceMin').value = 0;
  document.getElementById('catPriceMax').value = 50000;
  document.querySelectorAll('input[name="catstock"]').forEach(r => r.checked = r.value === 'toate');
  document.getElementById('catSortSelect').value = 'default';
  filterCatProducts();
}

function renderCatProducts(list) {
  document.getElementById('catProductsCount').textContent = list.length + ' produse găsite';
  document.getElementById('catHeroCount').textContent = list.length;
  const grid = document.getElementById('catProductsGrid');
  if (list.length === 0) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;">
      <div class="empty-state-icon">🔍</div>
      <h3>Niciun produs găsit</h3>
      <p>Încearcă să modifici filtrele</p>
    </div>`;
    return;
  }
  grid.innerHTML = list.map(p => productCardHTML(p)).join('');
}

function filterAllProducts() {
  const min = parseInt(document.getElementById('allPriceMin').value) || 0;
  const max = parseInt(document.getElementById('allPriceMax').value) || 999999;
  const cat = document.querySelector('input[name="pcat"]:checked').value;
  let list = products.filter(p => p.price >= min && p.price <= max);
  if (cat !== 'Toate') list = list.filter(p => p.cat === cat);
  document.getElementById('allProductsCount').textContent = list.length + ' produse găsite';
  document.getElementById('allProductsGrid').innerHTML = list.map(p => productCardHTML(p)).join('');
}

function resetAllFilters() {
  document.getElementById('allPriceMin').value = 0;
  document.getElementById('allPriceMax').value = 50000;
  document.querySelectorAll('input[name="pcat"]').forEach(r => r.checked = r.value === 'Toate');
  filterAllProducts();
}

let searchTimeout;
function handleSearch(val) {
  clearTimeout(searchTimeout);
  if (!val.trim()) return;
  searchTimeout = setTimeout(() => {
    const q = val.trim().toLowerCase();
    const results = products.filter(p =>
      p.name.toLowerCase().includes(q) || p.cat.toLowerCase().includes(q)
    );
    document.getElementById('searchQuery').textContent = val.trim();
    document.getElementById('searchResultsDesc').textContent = results.length + ' rezultate pentru "' + val.trim() + '"';
    document.getElementById('searchResultsGrid').innerHTML = results.map(p => productCardHTML(p)).join('');
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById('page-search').classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, 300);
}

function productCardHTML(p) {
  return `
    <div class="product-card" onclick="void(0)">
      <div class="product-img">
        <img src="${p.img}" alt="${p.name}" loading="lazy"
             onerror="this.style.display='none'; if(!this.nextSibling || !this.nextSibling.classList || !this.nextSibling.classList.contains('product-icon-wrap')){let d=document.createElement('div');d.className='product-icon-wrap';d.textContent='${p.emoji}';this.parentElement.insertBefore(d,this.nextSibling);}">
        ${!p.inStock ? `<div class="out-of-stock-overlay"><span>Stoc epuizat</span></div>` : ''}
      </div>
      <div class="product-body">
        <div class="product-cat">${p.cat}</div>
        <div class="product-name">${p.name}</div>
        <div class="product-rating">
          <span class="stars">${'★'.repeat(Math.floor(p.rating))}${'☆'.repeat(5-Math.floor(p.rating))}</span>
          ${p.rating} (${p.reviews})
        </div>
        <div class="product-footer">
          <div class="product-price">${p.price.toLocaleString('ro')} MDL</div>
          <button class="btn-add" ${!p.inStock ? 'disabled' : ''} onclick="event.stopPropagation(); addToCart(${p.id})">
            🛒 Adaugă
          </button>
        </div>
      </div>
    </div>
  `;
}

function addToCart(id) {
  cartCount++;
  document.getElementById('cartBadge').textContent = cartCount;
  showToast();
}

function openCart() {
  alert(`Ai ${cartCount} produs(e) în coș.`);
}

function showToast() {
  const t = document.getElementById('toast');
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2000);
}

function toggleFaq(el) {
  el.parentElement.classList.toggle('open');
}

let seconds = 18*3600 + 45*60 + 32;
setInterval(() => {
  if (seconds > 0) seconds--;
  const h = String(Math.floor(seconds/3600)).padStart(2,'0');
  const m = String(Math.floor((seconds%3600)/60)).padStart(2,'0');
  const s = String(seconds%60).padStart(2,'0');
  const el = document.getElementById('timer');
  if (el) el.textContent = `${h}:${m}:${s}`;
}, 1000);

window.addEventListener('hashchange', () => {
  const hash = location.hash.replace('#','');
  if (hash) navigate(hash);
});

document.getElementById('homeProductsGrid').innerHTML = products.slice(0, 6).map(p => productCardHTML(p)).join('');
filterAllProducts();

const initHash = location.hash.replace('#','');
if (initHash) navigate(initHash);
